## Press blurbs

### Beequation Kids (96 words)

Beequation Kids is a calm maths puzzle game for children aged 5 to 12, from Trett Labs. In every
honeycomb, one number is made from two others; children spot it and tap it, with Indie the bee offering
hints and no clock to beat. Six worlds cover adding, times tables, fractions and a two-step Big Hive, with
stars, stickers and a puzzle every day. It has no ads, no accounts and collects no data. Nine levels and the daily puzzle are free; a subscription or a one-off Lifetime purchase, behind a grown-up check, unlocks all 35.

### Beequation Pro (98 words)

Beequation Pro is a quick daily maths puzzle for teens and adults, from Trett Labs. In every comb of hexagons,
exactly one number is two others added or multiplied together, and every puzzle is checked to have exactly
one answer. Each day brings a numbered hive with a streak and a shareable result grid, alongside a
60-second blitz and 64 levels across eight modes, including negatives and fractions. It has no ads, no
account and collects no data. The daily hive, the blitz and 12 levels are free; a subscription or a one-off Lifetime purchase unlocks all 64.

### Short boilerplate (both apps, 43 words)

Trett Labs Limited makes Beequation Pro and Beequation Kids, two maths puzzle games built on one idea: find
the number made from two others. Both apps are free to try, have no ads and collect no data. More at
https://beequation.com/

